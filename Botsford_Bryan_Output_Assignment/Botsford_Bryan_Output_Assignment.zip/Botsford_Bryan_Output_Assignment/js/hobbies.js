//asking what my favorite hobbies are
alert("Some of my favorite hobbies are");//Creats a popup asking the question
var hobbies = "football, playing video games, fixing broken phones."//Naming my variable
document.getElementById("hobbies").innerHTML = hobbies;//writes the answer to the question on the page