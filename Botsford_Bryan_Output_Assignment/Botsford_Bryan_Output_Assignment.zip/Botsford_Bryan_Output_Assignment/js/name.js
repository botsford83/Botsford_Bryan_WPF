//Asking_My_Name
alert("What is your name?");//creates a popup dislaying the question
var first_name = "Bryan";//adding first_name = Bryan as a variable
var last_name = "Botsford";// adding last_time = Botsford as a variable
document.getElementById("name").innerHTML = first_name + " " + last_name;//writes the answer on the page