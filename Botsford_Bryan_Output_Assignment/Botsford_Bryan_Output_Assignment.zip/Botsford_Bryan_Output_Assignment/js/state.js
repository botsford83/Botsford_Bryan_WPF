//asking what state I lived in
alert("I live in:");//Creates a popup asking a question
var state = "Nebraska"//Naming my variable
document.getElementById("state").innerHTML = state;//Writes the answer to the question on the page