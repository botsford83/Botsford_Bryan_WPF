//Asking a true or false question 
alert("I have been in the Army Reserves for 10 years");//creates a popup asking the question
var yes = true;//stating my variable yes is true
var no = false;//stating my variable no is false
(document.getElementById("army").innerHTML = yes);//writes the answer to the question on the page
alert("If you want to know anything more about me, just ask!");//Creates a popup asking a question.